public class SurveyClosed extends SurveyState{

  public SurveyClosed(Survey survey){
    super();
  }

  public void cancel(){
      // getSurvey().setState(new ());
  }
	public void open(){
      // getSurvey().setState(new ());
  }
	public void close(){
    //Does not have any Effect
  }
	public void finalise(){
      // getSurvey().setState(new SurveyFinalised(getSurvey()));
  }
	public void submit(){
      // getSurvey().setState(new ());
  }
}
