public class SurveyOpen extends SurveyState{

  public SurveyOpen(Survey survey){
    super();
  }

  public void cancel(){
      // getSurvey().setState(new ());
  }
	public void open(){
      // getSurvey().setState(new ());
  }
	public void close(){
      // getSurvey().setState(new SurveyClosed(getSurvey()));
  }
	public void finalise(){
      // getSurvey().setState(new ());
  }
	public void submit(){
      // getSurvey().setState(new ());
  }
}
