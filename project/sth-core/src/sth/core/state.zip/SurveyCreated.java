public class SurveyCreated extends SurveyState{

  public SurveyCreated(Survey survey){
    super();
  }

  public void cancel(){
      // getSurvey().setState(new ());
  }
	public void open(){
      // getSurvey().setState(new ());
  }
	public void close(){
      // getSurvey().setState(new ());
  }
	public void finalise(){
      // getSurvey().setState(new ());
  }
	public void submit(){
      // getSurvey().setState(new ());
  }
	public void getResults(){
      // getSurvey().setState(new ());
  }
}
