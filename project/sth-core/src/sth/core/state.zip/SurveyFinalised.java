public class SurveyFinalised extends SurveyState{

  public SurveyFinalised(Survey survey){
    super();
  }

  public void cancel(){
      // getSurvey().setState(new ());
  }
	public void open(){
      // getSurvey().setState(new ());
  }
	public void close(){
      // getSurvey().setState(new ());
  }
	public void finalise(){
    //Does not have any Effect
  }
	public void submit(){
      // getSurvey().setState(new ());
  }
}
